#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
from __future__ import (unicode_literals, division, absolute_import, print_function)

__license__   = 'GPL v3'
__copyright__ = '2011, Kovid Goyal <kovid@kovidgoyal.net>'
__docformat__ = 'restructuredtext en'

if False:
    # This is here to keep my python error checker from complaining about
    # the builtin functions that will be defined by the plugin loading system
    # You do not need this code in your plugins
    get_icons = get_resources = None

import re, os

from PyQt4.Qt import (QDialog, QGridLayout, QPushButton, QMessageBox, QLabel,
        QWidget, QVBoxLayout, QLineEdit, QIcon, QDialogButtonBox, QTimer, QTreeWidget, QTreeWidgetItem, QTreeWidgetItemIterator)

from calibre_plugins.bbcgf_ebook.config import plugin_prefs
from calibre.utils.config import prefs as cprefs
from calibre.ebooks.conversion.config import load_defaults
from calibre.customize.conversion import OptionRecommendation
from calibre.ptempfile import PersistentTemporaryFile
from calibre.gui2 import Dispatcher, info_dialog


class URLList(QWidget):

    def __init__(self, parent):
        QWidget.__init__(self, parent)
        self.ul = ul = QGridLayout()
        self.setLayout(self.ul)

        self.labelul = QLabel('URLs:')
        ul.addWidget(self.labelul, 0, 0, 1, 1)
        self.ulist = QTreeWidget(self)
        self.ulist.setColumnCount(1);
        self.ulist.headerItem().setText(0, 'URLs');
        self.ulist.setToolTip(_('The list of recipe URLs to be processed.\nInvalid URLs are ignored silently.'))
        ul.addWidget(self.ulist, 0, 1, 1, 1)

    def add_item(self, url):
        item = QTreeWidgetItem(self.ulist)
        item.setChildIndicatorPolicy(QTreeWidgetItem.DontShowIndicator)
        item.setText(0, url)

    def get_items(self):
        urls = []
        it = QTreeWidgetItemIterator(self.ulist)
        while it.value():
            item = it.value()
            urls.append(unicode(item.text(0)))
            it += 1
        return urls
        
    @property
    def urllist(self):
        return unicode(self.ulist.text())

class URL(QWidget):

    def __init__(self, parent):
        QWidget.__init__(self, parent)
        self.l = l = QGridLayout()
        self.setLayout(self.l)

        self.label = QLabel('URL:')
        l.addWidget(self.label, 0, 0, 1, 1)
        self.url_edit = QLineEdit(self)
        self.url_edit.setPlaceholderText('Enter the URL of a bbcgoodfood.com recipe to download')
        l.addWidget(self.url_edit, 0, 1, 1, 1)

    def clear(self):
        self.url_edit.clear()
    
    @property
    def url(self):
        return unicode(self.url_edit.text())
        
        
class Title(QWidget):

    def __init__(self, parent):
        QWidget.__init__(self, parent)
        self.ll = ll = QGridLayout()
        self.setLayout(self.ll)

        self.labell = QLabel('Title:')
        ll.addWidget(self.labell, 0, 0, 1, 1)
        self.title_edit = QLineEdit(self)
        self.title_edit.setPlaceholderText('Enter a title for the ebook ')
        ll.addWidget(self.title_edit, 0, 1, 1, 1)
        
    @property
    def title(self):
        return unicode(self.title_edit.text())       


def get_recipe(urls, title):
    fmt = cprefs['output_format'].lower()
    
    pt = PersistentTemporaryFile(suffix='_recipe_out.%s'%fmt.lower())
    pt.close()
    recs = []
    ps = load_defaults('page_setup')
    if 'output_profile' in ps:
        recs.append(('output_profile', ps['output_profile'],
            OptionRecommendation.HIGH))

    lf = load_defaults('look_and_feel')
    if lf.get('base_font_size', 0.0) != 0.0:
        recs.append(('base_font_size', lf['base_font_size'],
            OptionRecommendation.HIGH))
        recs.append(('keep_ligatures', lf.get('keep_ligatures', False),
            OptionRecommendation.HIGH))

    lr = load_defaults('lrf_output')
    if lr.get('header', False):
        recs.append(('header', True, OptionRecommendation.HIGH))
        recs.append(('header_format', '%t', OptionRecommendation.HIGH))

    epub = load_defaults('epub_output')
    if epub.get('epub_flatten', False):
        recs.append(('epub_flatten', True, OptionRecommendation.HIGH))

    recipe = get_resources('bbcgf.recipe')
    url_line = bytes(repr(urls))
    recipe = re.sub(br'^(\s+urls = ).+?# REPLACE_ME_URLS', br'\1'+url_line, recipe, flags=re.M)
    if title.strip():
        title_line = bytes(repr(title))
        recipe = re.sub(br'^(\s+title\s+=\s+)DEFAULT_TITLE', br'\1'+title_line, recipe, flags=re.M)
    logo = get_resources('images/cover.jpg')
    lf = PersistentTemporaryFile('_bbcgf_logo.png')
    lf.write(logo)
    recipe = recipe.replace(b'LOGO = None', b'LOGO = %r'%lf.name)
    lf.close()
    rf = PersistentTemporaryFile(suffix='_bbcgf.recipe')
    rf.write(recipe)
    rf.close()
    args = [rf.name, pt.name, recs]
    return args, fmt.upper(), [pt, rf, lf]

class BBCGFDialog(QDialog):

    def __init__(self, gui, icon, do_user_config):
        QDialog.__init__(self, gui)
        self.gui = gui
        self.do_user_config = do_user_config

        # The current database shown in the GUI
        # db is an instance of the class LibraryDatabase2 from database.py
        # This class has many, many methods that allow you to do a lot of
        # things.
        self.db = gui.current_db

        self.l = QVBoxLayout()
        self.setLayout(self.l)

        self.setWindowTitle('BBC GoodFood Recipe Reader')
        self.setWindowIcon(icon)

        #self.about_button = QPushButton('About', self)
        #self.about_button.clicked.connect(self.about)
        #self.l.addWidget(self.about_button)

        self.helpl = QLabel('Enter the URL of a bbcgoodfood.com recipe below.'
                ' It will be downloaded and converted into an ebook.')
        self.helpl.setWordWrap(True)
        self.l.addWidget(self.helpl)
        
        self.title = title = Title(self)
        self.l.addWidget(self.title)

        self.ulist = URLList(self)
        self.l.addWidget(self.ulist)

        self.urls = URL(self)
        self.l.addWidget(self.urls)

        self.add_more_button = QPushButton(QIcon(I('plus.png')), 'Add URL')
        self.add_more_button.setToolTip(_('Add the URL in the URL field to the list of URLs to be processed.'))
        self.l.addWidget(self.add_more_button)

        self.bb = QDialogButtonBox(self)
        self.bb.setStandardButtons(self.bb.Ok|self.bb.Cancel)
        self.bb.accepted.connect(self.accept)
        self.bb.rejected.connect(self.reject)
        self.l.addWidget(self.bb)

        self.add_more_button.clicked.connect(self.add_url)
        self.finished.connect(self.download)

        self.setMinimumWidth(500)
        self.resize(self.sizeHint())

    def do_resize(self):
        self.resize(self.sizeHint())

    def add_url(self):
        self.ulist.add_item(self.urls.url);
        self.urls.clear()

    def about(self):
        # Get the about text from a file inside the plugin zip file
        # The get_resources function is a builtin function defined for all your
        # plugin code. It loads files from the plugin zip file. It returns
        # the bytes from the specified file.
        #
        # Note that if you are loading more than one file, for performance, you
        # should pass a list of names to get_resources. In this case,
        # get_resources will return a dictionary mapping names to bytes. Names that
        # are not found in the zip file will not be in the returned dictionary.
        text = get_resources('about.txt')
        QMessageBox.about(self, 'About the BBC GoodFood Recipe Reader',
                text.decode('utf-8'))

    # def config(self):
    #     self.do_user_config(parent=self)
    #     # Apply the changes
    #     self.label.setText(prefs['hello_world_msg'])

    def download(self, retcode):
        if retcode != self.Accepted:
            return
        urls = self.ulist.get_items()
        
        print(urls)
        urls = [x.strip() for x in urls if x.strip()]
        args, fmt, temp_files = get_recipe(urls, self.title.title)
        job = self.gui.job_manager.run_job(Dispatcher(self.fetched), 'gui_convert', args=args, description='Fetch recipe from bbcgoodfood.com')
        job.extra_conversion_args = (temp_files, fmt)
        if plugin_prefs['hidedldlg'] == False:
            info_dialog(self, 'Downloading',
                    'Downloading %d recipe(s) from bbcgoodfood.com. When the download'
                    ' completes the book will be added to your calibre library.'
                    %len(urls), show=True, show_copy_button=False)

    def fetched(self, job):
        if job.failed:
            return self.gui.job_exception(job)
        temp_files, fmt = job.extra_conversion_args
        fname = temp_files[0].name
        self.gui.iactions['Add Books']._add_books([fname], False)
        for f in temp_files[1:]:
            try:
                os.remove(f.name)
            except:
                pass
        self.gui.status_bar.show_message('BBC GoodFood recipes fetched.', 3000)

