#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
from __future__ import (unicode_literals, division, absolute_import, print_function)

__license__   = 'GPL v3'
__copyright__ = '2012, Gary Harris'
__docformat__ = 'restructuredtext en'

from PyQt4.Qt import (Qt, QWidget, QVBoxLayout, QCheckBox, QPushButton)

from calibre.gui2 import dynamic, info_dialog
from calibre.utils.config import JSONConfig

from calibre_plugins.bbcgf_ebook.common_utils import (get_library_uuid, KeyboardConfigDialog, PrefsViewerDialog)

#PREFS_NAMESPACE = 'BBCGoodFoodRecipeReaderPlugin'
#PREFS_KEY_SETTINGS = 'settings'


    
# This is where all preferences for this plugin will be stored
plugin_prefs = JSONConfig('plugins/BBC GoodFood Recipe Reader')

# Set defaults
plugin_prefs.defaults['hidedldlg'] = False

    
class ConfigWidget(QWidget):

    def __init__(self, plugin_action):
        QWidget.__init__(self)
        self.plugin_action = plugin_action
        
        self.l = QVBoxLayout()
        self.setLayout(self.l)

        self.cb_widget = QCheckBox('Don\'t show the download information message box.', self)
        self.l.addWidget(self.cb_widget)
        hidedldlg = plugin_prefs['hidedldlg']
        self.cb_widget.setChecked(Qt.Checked if hidedldlg else Qt.Unchecked)
        self.cb_widget.setToolTip('When this option is checked, the message box that displays information\n'
                                              'when downloading recipes will not appear.\n'
                                              'When unchecked the message box will appear and require closing manually.\n\n'
                                              'The other system messages that appear are unaffected.')
                      
        self.keyboard_shortcuts_button = QPushButton('Keyboard shortcuts...', self)
        self.keyboard_shortcuts_button.setToolTip(_('Edit the keyboard shortcuts associated with this plugin'))
        self.keyboard_shortcuts_button.clicked.connect(self.edit_shortcuts)
        self.l.addWidget(self.keyboard_shortcuts_button)

    def save_settings(self):
        plugin_prefs['hidedldlg'] = self.cb_widget.isChecked()
        

    def edit_shortcuts(self):
        self.save_settings()
        d = KeyboardConfigDialog(self.plugin_action.gui, self.plugin_action.action_spec[0])
        if d.exec_() == d.Accepted:
            self.plugin_action.gui.keyboard.finalize()

